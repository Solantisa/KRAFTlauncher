Credits; Shwoom Store 2022 - 2024©

To setup this;

1-) Open The Microsoft Store

2-) Search up "Minecraft: Java & Bedrock EDition for PC" and click on it

3-) Swipe down and you'll see "In this Bundle" text

4-) Look for "Minecraft for Windows" bundle and open it up

5-) Download and when the downloading finishes, open the "Launcher" app on this folder.

6-) Enjoy! <3